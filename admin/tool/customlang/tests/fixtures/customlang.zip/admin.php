<?php
* $string['accounts'] = 'Accounts-custom_import';
?>