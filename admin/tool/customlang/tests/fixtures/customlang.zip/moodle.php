<?php
* $string['accept'] = 'Accept-custom_import';
?>